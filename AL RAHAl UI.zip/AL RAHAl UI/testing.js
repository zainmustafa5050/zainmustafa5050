console.log('Testing.js file loaded');

document.addEventListener("DOMContentLoaded", function(){
  console.log('DOM content loaded');
  var button = document.getElementById("addToCart");
  console.log('Button element:', button);
  console.log('Button element parent:', button.parentNode);
  
  // Check if the button element is available in the jQuery context
  console.log('jQuery button element:', $('#addToCart')[0]);
  
  // Rest of the code...
});