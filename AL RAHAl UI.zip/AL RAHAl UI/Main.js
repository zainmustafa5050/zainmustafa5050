
var modal = document.getElementById("myModal");
var modalImage = document.getElementById("modalImage");

// Get all elements with the class addToCart
var addToCartButtons = document.querySelectorAll(".addToCart");

// Loop through each button and attach an event listener
addToCartButtons.forEach(function(button) {
button.addEventListener("click", function(event) {
// Get the image source from the parent element
var originalImage = button.parentNode.querySelector("img");

// Set the modal image source
modalImage.src = originalImage.src;

// Show the modal
modal.style.display = "block";

// Prevent the default button behavior
event.preventDefault();
return false;
});
});
